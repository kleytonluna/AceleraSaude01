# Acelera Saúde - ASP.NET Core

Este projeto é uma conversão do sistema PHP/HTML original "Acelera Saúde" para ASP.NET Core MVC.

## Funcionalidades

- **Cadastro de Usuários**: Permite que novos usuários se registrem no sistema
- **Login de Usuários**: Autenticação de usuários existentes
- **Marcação de Consultas**: Agendamento de consultas médicas
- **Marcação de Exames**: Agendamento de exames médicos
- **Portal do Paciente**: Área restrita para usuários logados

## Tecnologias Utilizadas

- ASP.NET Core 8.0 MVC
- Entity Framework Core
- MySQL (Pomelo.EntityFrameworkCore.MySql)
- Bootstrap (para responsividade)
- JavaScript (validações client-side)

## Estrutura do Banco de Dados

### Tabela: Usuarios
- Id (int, PK, auto-increment)
- Nome (varchar(100))
- Email (varchar(100), unique)
- Cpf (varchar(14), unique)
- Senha (varchar(255))
- DataCadastro (datetime)

### Tabela: Marcacoes
- Id (int, PK, auto-increment)
- Nome (varchar(100))
- Data (date)
- Hora (time)
- Especialidade (varchar(50))
- DataCriacao (datetime)

### Tabela: Exames
- Id (int, PK, auto-increment)
- Nome (varchar(100))
- Data (date)
- Hora (time)
- Especialidade (varchar(50))
- DataCriacao (datetime)

## Configuração

### Pré-requisitos
- .NET 8.0 SDK
- MySQL Server
- Visual Studio ou VS Code

### Configuração do Banco de Dados

1. Certifique-se de que o MySQL está rodando
2. Crie um banco de dados chamado `acelera_saude`
3. Ajuste a connection string no `appsettings.json` se necessário:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=acelera_saude;Uid=root;Pwd=;"
  }
}
```

### Executar Migrações

```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### Executar o Projeto

```bash
dotnet run
```

O projeto estará disponível em `https://localhost:5001` ou `http://localhost:5000`.

## Rotas Principais

- `/` - Página inicial
- `/Account/Login` - Página de login
- `/Account/Cadastro` - Página de cadastro
- `/Portal/TelaPrincipal` - Portal do paciente (requer login)
- `/Portal/Marcacao` - Marcação de consultas (requer login)
- `/Portal/Exames` - Marcação de exames (requer login)

## Melhorias Implementadas

### Segurança
- Validação de entrada nos formulários
- Proteção contra SQL Injection usando Entity Framework
- Validação de sessão para páginas protegidas
- Validação de senha com critérios específicos

### Usabilidade
- Máscaras para CPF
- Validação em tempo real de senhas
- Alertas informativos
- Prevenção de agendamentos em datas passadas
- Interface responsiva

### Arquitetura
- Padrão MVC bem estruturado
- ViewModels para formulários
- Separação de responsabilidades
- Configuração centralizada

## Diferenças do Sistema PHP Original

1. **Segurança**: Implementação de validações mais robustas
2. **Arquitetura**: Estrutura MVC organizada vs. arquivos PHP soltos
3. **Banco de Dados**: Uso do Entity Framework vs. consultas SQL diretas
4. **Sessões**: Sistema de sessões do ASP.NET Core vs. sessões PHP
5. **Validações**: Validações client-side e server-side integradas
6. **Responsividade**: Layout adaptável para dispositivos móveis

## Próximos Passos

Para produção, considere implementar:

1. **Hash de senhas**: Implementar BCrypt ou similar para senhas
2. **Identity Framework**: Migrar para ASP.NET Core Identity
3. **Logs**: Implementar sistema de logs estruturado
4. **Testes**: Adicionar testes unitários e de integração
5. **Docker**: Containerização da aplicação
6. **CI/CD**: Pipeline de deploy automatizado

## Estrutura de Arquivos

```
AceleraSaude/
├── Controllers/
│   ├── AccountController.cs
│   ├── HomeController.cs
│   └── PortalController.cs
├── Data/
│   └── ApplicationDbContext.cs
├── Models/
│   ├── ViewModels/
│   │   ├── CadastroViewModel.cs
│   │   └── LoginViewModel.cs
│   ├── Exame.cs
│   ├── Marcacao.cs
│   └── Usuario.cs
├── Views/
│   ├── Account/
│   │   ├── Cadastro.cshtml
│   │   └── Login.cshtml
│   ├── Home/
│   │   └── Index.cshtml
│   ├── Portal/
│   │   ├── Exames.cshtml
│   │   ├── Marcacao.cshtml
│   │   └── TelaPrincipal.cshtml
│   └── Shared/
│       ├── _Layout.cshtml
│       └── _LayoutAceleraSaude.cshtml
├── wwwroot/
│   ├── css/
│   │   └── acelera-saude.css
│   ├── img/
│   └── js/
│       └── acelera-saude.js
├── appsettings.json
├── Program.cs
└── README.md
```
