// JavaScript para o projeto Acelera Saúde

document.addEventListener('DOMContentLoaded', function() {
    // Máscara para CPF
    const cpfInputs = document.querySelectorAll('input[name="Cpf"]');
    cpfInputs.forEach(function(input) {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d)/, '$1.$2');
            value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            e.target.value = value;
        });
    });

    // Validação de formulários
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(function(field) {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#dc3545';
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Por favor, preencha todos os campos obrigatórios.');
            }
        });
    });

    // Auto-hide de alertas
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.style.display = 'none';
            }, 300);
        }, 5000);
    });

    // Validação de data (não pode ser no passado)
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        const today = new Date().toISOString().split('T')[0];
        input.setAttribute('min', today);
    });

    // Validação de senha em tempo real
    const senhaInput = document.querySelector('input[name="Senha"]');
    const confirmacaoInput = document.querySelector('input[name="ConfirmacaoSenha"]');
    
    if (senhaInput) {
        senhaInput.addEventListener('input', function(e) {
            const senha = e.target.value;
            const feedback = document.getElementById('senha-feedback') || createPasswordFeedback();
            
            let messages = [];
            if (senha.length < 8) {
                messages.push('Mínimo 8 caracteres');
            }
            if (!/[A-Za-z]/.test(senha)) {
                messages.push('Pelo menos uma letra');
            }
            if (!/[0-9]/.test(senha)) {
                messages.push('Pelo menos um número');
            }
            
            if (messages.length === 0) {
                feedback.textContent = 'Senha válida ✓';
                feedback.className = 'text-success';
            } else {
                feedback.textContent = 'Necessário: ' + messages.join(', ');
                feedback.className = 'text-danger';
            }
        });
    }

    if (confirmacaoInput) {
        confirmacaoInput.addEventListener('input', function(e) {
            const confirmacao = e.target.value;
            const senha = senhaInput.value;
            const feedback = document.getElementById('confirmacao-feedback') || createConfirmationFeedback();
            
            if (confirmacao === senha) {
                feedback.textContent = 'Senhas coincidem ✓';
                feedback.className = 'text-success';
            } else {
                feedback.textContent = 'Senhas não coincidem';
                feedback.className = 'text-danger';
            }
        });
    }

    function createPasswordFeedback() {
        const feedback = document.createElement('div');
        feedback.id = 'senha-feedback';
        feedback.className = 'text-muted';
        feedback.style.fontSize = '0.875rem';
        senhaInput.parentNode.appendChild(feedback);
        return feedback;
    }

    function createConfirmationFeedback() {
        const feedback = document.createElement('div');
        feedback.id = 'confirmacao-feedback';
        feedback.className = 'text-muted';
        feedback.style.fontSize = '0.875rem';
        confirmacaoInput.parentNode.appendChild(feedback);
        return feedback;
    }
});
