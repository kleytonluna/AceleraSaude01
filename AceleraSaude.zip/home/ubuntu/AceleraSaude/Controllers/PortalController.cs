using Microsoft.AspNetCore.Mvc;
using AceleraSaude.Data;
using AceleraSaude.Models;

namespace AceleraSaude.Controllers
{
    public class PortalController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PortalController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult TelaPrincipal()
        {
            // Verificar se usuário está logado
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        [HttpGet]
        public IActionResult Marcacao()
        {
            // Verificar se usuário está logado
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new Marcacao());
        }

        [HttpPost]
        public async Task<IActionResult> Marcacao(Marcacao model)
        {
            // Verificar se usuário está logado
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Validar data não pode ser no passado
                if (model.Data.Date < DateTime.Now.Date)
                {
                    TempData["ErrorMessage"] = "A data da consulta não pode ser no passado.";
                    return View(model);
                }

                _context.Marcacoes.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"A CONSULTA DE {model.Nome} FOI MARCADA NA Data: {model.Data:dd/MM/yyyy} E Hora: {model.Hora}";
                return RedirectToAction("TelaPrincipal");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "NÃO FOI POSSÍVEL MARCAR A CONSULTA DO USUÁRIO!";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Exames()
        {
            // Verificar se usuário está logado
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new Exame());
        }

        [HttpPost]
        public async Task<IActionResult> Exames(Exame model)
        {
            // Verificar se usuário está logado
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("UserId")))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Validar data não pode ser no passado
                if (model.Data.Date < DateTime.Now.Date)
                {
                    TempData["ErrorMessage"] = "A data do exame não pode ser no passado.";
                    return View(model);
                }

                _context.Exames.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"O EXAME DE {model.Nome} FOI AGENDADO NA Data: {model.Data:dd/MM/yyyy}, Hora: {model.Hora}";
                return RedirectToAction("TelaPrincipal");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "NÃO FOI POSSÍVEL MARCAR O EXAME DO USUÁRIO!";
                return View(model);
            }
        }
    }
}
