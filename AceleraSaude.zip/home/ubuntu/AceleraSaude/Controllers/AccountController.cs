using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AceleraSaude.Data;
using AceleraSaude.Models;
using AceleraSaude.Models.ViewModels;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace AceleraSaude.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Buscar usuário pelo email
                var usuario = await _context.Usuarios
                    .FirstOrDefaultAsync(u => u.Email == model.Email);

                if (usuario == null)
                {
                    TempData["ErrorMessage"] = "EMAIL NÃO CADASTRADO.";
                    return View(model);
                }

                // Verificar senha (comparação direta por compatibilidade com PHP)
                if (usuario.Senha != model.Senha)
                {
                    TempData["ErrorMessage"] = "SENHA INCORRETA.";
                    return View(model);
                }

                // Armazenar informações do usuário na sessão
                HttpContext.Session.SetString("UserId", usuario.Id.ToString());
                HttpContext.Session.SetString("UserName", usuario.Nome);
                HttpContext.Session.SetString("UserEmail", usuario.Email);

                return RedirectToAction("TelaPrincipal", "Portal");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Erro interno do servidor. Tente novamente.";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Cadastro()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Cadastro(CadastroViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Validar senha
                if (!ValidarSenha(model.Senha))
                {
                    TempData["ErrorMessage"] = "A senha deve ter pelo menos 8 caracteres, conter pelo menos uma letra e um número.";
                    return View(model);
                }

                // Verificar se usuário já existe
                var usuarioExistente = await _context.Usuarios
                    .FirstOrDefaultAsync(u => u.Email == model.Email || u.Cpf == model.Cpf);

                if (usuarioExistente != null)
                {
                    TempData["ErrorMessage"] = "Usuário já cadastrado com este e-mail ou CPF!";
                    return View(model);
                }

                // Criar novo usuário
                var usuario = new Usuario
                {
                    Nome = model.Nome,
                    Email = model.Email,
                    Cpf = model.Cpf,
                    Senha = model.Senha, // Por compatibilidade com PHP, não usar hash por enquanto
                    DataCadastro = DateTime.Now
                };

                _context.Usuarios.Add(usuario);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "USUÁRIO CADASTRADO!";
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "NÃO FOI POSSÍVEL CADASTRAR O USUÁRIO!";
                return View(model);
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        private bool ValidarSenha(string senha)
        {
            if (senha.Length < 8)
                return false;

            if (!Regex.IsMatch(senha, @"[A-Za-z]"))
                return false;

            if (!Regex.IsMatch(senha, @"[0-9]"))
                return false;

            return true;
        }

        private string HashSenha(string senha)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(senha));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
}
