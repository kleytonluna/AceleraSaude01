using Microsoft.EntityFrameworkCore;
using AceleraSaude.Models;

namespace AceleraSaude.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Marcacao> Marcacoes { get; set; }
        public DbSet<Exame> Exames { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurações adicionais para os modelos
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasIndex(e => e.Email).IsUnique();
                entity.HasIndex(e => e.Cpf).IsUnique();
            });

            modelBuilder.Entity<Marcacao>(entity =>
            {
                entity.Property(e => e.Data).HasColumnType("date");
                entity.Property(e => e.Hora).HasColumnType("time");
            });

            modelBuilder.Entity<Exame>(entity =>
            {
                entity.Property(e => e.Data).HasColumnType("date");
                entity.Property(e => e.Hora).HasColumnType("time");
            });
        }
    }
}
